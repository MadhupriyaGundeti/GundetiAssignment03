package Q22;

import java.util.*;  
class ImmutableString{    
    public static void main(String args[]){    
        String NewString = "Hello";    
        NewString = NewString.concat("World");  
        System.out.println(NewString);    
    }    
} 