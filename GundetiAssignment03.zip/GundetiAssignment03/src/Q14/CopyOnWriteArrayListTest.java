package Q14;

import java.util.*;
import java.util.concurrent.*;
public class CopyOnWriteArrayListTest {
   public static void main(String[] args) {
      CopyOnWriteArrayList list = new CopyOnWriteArrayList();
      list.add("Java");
      list.add("Scala");
      list.add("Python");
      list.add("Selenium");
      list.add("ServiceNow");
      System.out.println("Displaying synchronized ArrayList: ");
      Iterator itr = list.iterator();
      while(itr.hasNext()) {
        // String str = itr.next();
       //  System.out.println(str);
      }
   }
}
