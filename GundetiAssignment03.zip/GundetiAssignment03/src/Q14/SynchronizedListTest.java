package Q14;

import java.util.*;
public class SynchronizedListTest {
   public static void main(String[] args) {
      List<String> list = new ArrayList<String>();
      list.add("IND");
      list.add("AUS");
      list.add("WI");
      list.add("NZ");
      list.add("ENG");
      List<String> synlist = Collections.synchronizedList(list);
      synchronized(synlist) {
         Iterator<String> itr = synlist.iterator();
         while(itr.hasNext()) {
            String str = itr.next();
            System.out.println(str);
         }
      }
   }
}
