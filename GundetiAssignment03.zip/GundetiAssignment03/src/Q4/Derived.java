package Q4;

class Derived extends Base {
	  public void fun() {  // overrides the Base's fun()
	     System.out.println("Derived fun");    
	  }
	  public static void main(String[] args) {
	      Base obj = new Derived();
	      obj.fun();
	  } 
	}
