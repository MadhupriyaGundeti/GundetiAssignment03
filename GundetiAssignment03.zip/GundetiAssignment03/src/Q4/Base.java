package Q4;

class Base {
	  public void fun() {
	     System.out.println("Base fun");    
	  }
	}
