package Q3;

class A2 extends A1  
{  
    @Override  
    A2 foo()  
    {  
        return this;  
    }  
      
    void print()  
    {  
        System.out.println("Inside the class A2");  
    }  
}
