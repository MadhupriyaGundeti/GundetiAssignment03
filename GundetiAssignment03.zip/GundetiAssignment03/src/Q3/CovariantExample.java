package Q3;

public class CovariantExample  
{  
    // main method  
    public static void main(String argvs[])  
    {  
       A1 a1 = new A1();  
         
       a1.foo().print();  
         
       A2 a2 = new A2();  
         
       a2.foo().print();  
         
       A3 a3 = new A3();  
         
       a3.foo().print();  
         
    }  
}  
