package Q10;

import java.io.*;

class SuperClass {
 
    // SuperClass doesn't declare any exception
    void method()
    {
        System.out.println("SuperClass");
    }
}