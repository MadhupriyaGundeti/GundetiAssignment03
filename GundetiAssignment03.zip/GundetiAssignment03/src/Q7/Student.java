package Q7;

public class Student {
	   public final String name;
	   public final int age;
	  // public final Student(){
	   //   this.name = "Raju";
	    //  this.age = 20;
	   //}
	   public Student(){
		      this.name = "Raju";
		      this.age = 20;
	   }
	   public void display(){
	      System.out.println("Name of the Student: "+this.name );
	      System.out.println("Age of the Student: "+this.age );
	   }
	   public static void main(String args[]) {
	      new Student().display();
	   }
	}